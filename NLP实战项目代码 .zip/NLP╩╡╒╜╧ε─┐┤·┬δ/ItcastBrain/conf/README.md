##Configuration instructions
* nginx conf --> nginx -t 
* webapp conf --> ../config.py
* celery conf --> ../server/setting
---

* redis.conf
* supervisord.conf
* uwsgi.ini 
