
from django.conf.urls import url
from django.contrib import admin
from Info import views as i_views
from Yxb import views as y_views


urlpatterns = [
    url(r'^admin/', admin.site.urls),
    # 外部请求的uri直接指向i_views中的get_info函数
    url(r'^api/v1/get_info[/]?$', i_views.get_info),
    url(r'^api/v1/get_trans[/]?$', y_views.get_trans),
]
