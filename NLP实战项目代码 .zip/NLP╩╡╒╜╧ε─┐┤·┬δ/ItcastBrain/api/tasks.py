#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jul 31 17:18:47 2017

@author: zhoumingzhen
"""
from __future__ import absolute_import, unicode_literals

from calc_tag_score.task import update_local_tag_words
