# coding:utf-8

import time
import threading

# 初始化采集结果的列表
result = []


# 以下是四个示例函数：

def func1(x, y, z):
    time.sleep(3)
    result.append(x + y + z)


def func2(x, y):
    time.sleep(2)
    result.append(x + y)


def func3(x):
    time.sleep(1)
    result.append(x)


def func4(x, y, z, u):
    time.sleep(7)
    result.append(x + y + z + u)


def _start_thread(func_params):
    """开启预测线程, 执行对应的函数"""
    t = threading.Thread(target=func_params[0], args=(func_params[1:]))
    t.start()
    return t


if __name__ == "__main__":
    start = time.time()
    # 将需要执行的函数和对应的参数组成列表
    func_list = [(func1, 1, 2, 3), (func2, 1, 2), (func3, 1), (func4, 1, 2, 3, 4)]
    # 逐个开启线程
    t_list = list(map(lambda func_params: _start_thread(func_params), func_list))
    # 线程将逐一join操作等待所有线程完成
    list(map(lambda t: t.join(), t_list))
    end = time.time()
    print(end - start)
    print(result)
