# coding:utf-8

import requests
import time

url = "http://0.0.0.0:8087/api/v1/get_info"

data = {
    "sessionId": "23243",
    "ip": "中国 北京 北京",
    "fromTitle": "黑马程序员C/C++与网络攻防培训官网-C/C++培训|C/C++与网络攻防培训机构",
    "content": [
        {"employee": "你好，你是想了解哪个课程呢？¥还在么同学？", "customer": "价格？"},
        {"employee": "您好¥您想了解哪个专业的学费呢¥专业不同，学时学费也不一样", "customer": "C++"},
        {"employee": "贵姓", "customer": "周"},
        {"employee": "请问您的联系方式是,方便下次和您联系", "customer": "15212341234"},
        {"employee": "好的，可以给您发送一份C++的课程资料，学时学费和学习路线，您可以先了解看下", "customer": "好"},
    ],
}

start = time.time()

res = requests.post(url, json=data)

end = time.time()

print("总耗时:", end-start)
print(res.text)