# coding:utf-8

import fasttext
import pandas as pd
import jieba

# 训练数据路径
train_data_path = "./name_question.train"
# 验证数据路径
valid_data_path = "./name_question.valid"

# 词粒度存储路径
word_train_data_path = "./name_question.train.2"
word_valid_data_path = "./name_question.valid.2"


# 读取训练数据，分隔符为空格
df1 = pd.read_csv(train_data_path, header=None, sep=" ")
df2 = pd.read_csv(valid_data_path, header=None, sep=" ")

# 使用词的形式进行训练
df1[1] = pd.DataFrame(map(lambda x: " ".join(jieba.cut(x)), df1[1]))
df2[1] = pd.DataFrame(map(lambda x: " ".join(jieba.cut(x)), df2[1]))


# 生成训练数据
df1.to_csv(word_train_data_path, header=False, index=False, sep="\t")
# 生成验证数据
df2.to_csv(word_valid_data_path, header=False, index=False, sep="\t")

# 进行模型训练，这里我们将n-gram特征设置为2
# 其他参数都是用默认，如：embed_size为100，训练轮数epoch为5
# model = fasttext.train_supervised(input=word_train_data_path, wordNgrams=2)

model = fasttext.train_supervised(
    input=word_train_data_path,
    autotuneValidationFile=word_valid_data_path,
    autotuneDuration=600,
    wordNgrams=2,
)

# 之后我们在验证集上进行验证
valid_result = model.test(word_valid_data_path)
print(valid_result)