# coding:utf-8

import fasttext

# 实例化一个模型,并且开始训练
model = fasttext.train_unsupervised("unsupervised_data.txt", "skipgram", dim=150, epoch=5,
                                    lr=0.1, thread=8)

# 获取一个bin格式的模型
model.save_model("unsupervised_data.bin")

