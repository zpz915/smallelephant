# coding:utf-8

import fasttext
import pandas as pd

# 获取训练数据\验证数据路径
train_data_path = "./name_question.train"
valid_data_path = "./name_question.valid"

# 指定字粒度存储路径
char_train_data_path = "./name_question.train.1"
char_valid_data_path = "./name_question.valid.1"

# 读取训练数据
df1 = pd.read_csv(train_data_path, header=None, sep=" ")
df2 = pd.read_csv(valid_data_path, header=None, sep=" ")

# 把文本转为中间添加空格模式:
# "您叫什么名字?" --> "您 叫 什 么 名 字 ?"
df1[1] = pd.DataFrame(map(lambda x: " ".join(list(x)), df1[1]))
df2[1] = pd.DataFrame(map(lambda x: " ".join(list(x)), df2[1]))

# 保存以字向量为格式的训练集和验证集
df1.to_csv(char_train_data_path, header=False, index=False, sep="\t")
df2.to_csv(char_valid_data_path, header=False, index=False, sep="\t")

# 进行模型训练
# 初步模型训练
model = fasttext.train_supervised(input=char_train_data_path, wordNgrams=2)

# 模型自动超参数调优训练
# model = fasttext.train_supervised(
#     input=char_train_data_path,
#     autotuneValidationFile=char_valid_data_path,
#     autotuneDuration=600,
#     wordNgrams=2,
#     verbose=3
# )

# 在验证集上进行验证
valid_result = model.test(char_valid_data_path)
# print(valid_result)

# ========================
# 绘制使用自动超参数调优前后的效果对比图
import matplotlib.pyplot as plt

# 设置背景风格
plt.switch_backend("Agg")


# 定义绘图函数
def plot(metric, metric_name, labels, fig_name):
    """
    图形绘制
    :param metric: 需要评估对比的指标-列表
    :param metric_name: 评估指标名称
    :param labels: 对比试验名称列表
    :param fig_name: 图保存名称
    :return: None
    """
    # 初始化画布和轴
    fig, ax = plt.subplots()

    # 使用柱状体进行绘制
    ax.bar([0, 1], metric)

    # 设置纵坐标
    ax.set_ylabel(metric_name)

    # 设置横轴刻度
    ax.set_xticks([0, 1])

    # 设置横轴名称
    ax.set_xticklabels(labels)

    # 添加表格线
    ax.yaxis.grid(True)

    # 设置布局
    plt.tight_layout()

    # 保存画布,并且关闭
    plt.savefig(fig_name)
    plt.close(fig)


if __name__ == '__main__':
    # 两次的精度结果
    precision = [0.882, 0.922]
    # 两次的召回率结果
    recall = [0.871, 0.898]

    plot(precision, "precision", ["before", "after"], "./img/at_pre.png")
    plot(recall, "recall", ["before", "after"], "./img/at_recall.png")

# ========================
# 模型保存
import time

time_ = int(time.time())
model_save_path = "./name_question_{}.bin".format(time_)
model.save_model(model_save_path)

# ========================
# 模型预测
model = fasttext.load_model(model_save_path)
# 进行预测
res = model.predict(" ".join(list("同学你还在线吗?")))
print(res)

res = model.predict(" ".join(list("同学,贵姓?")))
print(res)
