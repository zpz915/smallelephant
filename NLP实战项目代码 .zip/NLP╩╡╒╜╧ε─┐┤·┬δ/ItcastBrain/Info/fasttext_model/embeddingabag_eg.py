# coding:utf-8

# ===============================
# embeddingbag举例
import torch
import torch.nn as nn


# # 初始化三个参数
# # 预料中所有的词表
# vocab_size = 10
#
# # 词嵌入维度
# embed_dim = 3
#
# # 实例化一个embeddingbag
# embedding = nn.EmbeddingBag(vocab_size, embed_dim, mode="mean")
#
# # 随时设定一段文本映射后的数字
# input = torch.LongTensor([1, 3, 5, 2, 3, 6, 8])
#
# # 设置offsets, 用于标记每个bag的开始位置
# offsets = torch.LongTensor([0, 4, 6])
#
# print(embedding(input, offsets))

# ===============================
# fasttext举例


class FastText(nn.Module):
    """创建fasttext模型的类"""

    def __init__(self, vocab_size, embed_dim, num_class):
        """
        初始化需要的变量
        :param vocab_size:语料中所有不重复的词
        :param embed_dim: 词嵌入维度
        :param num_class: 目标的类别数
        """
        super().__init__()

        # 初始化embeddingbag层
        self.embedding = nn.EmbeddingBag(vocab_size, embed_dim, sparse=True)

        # 初始化全连接层
        self.fc = nn.Linear(embed_dim, num_class)

        # 初始化权重
        self.init_weights()

    def init_weights(self):
        """
        初始化权重函数
        :return: None
        """
        # 初始定义数值范围
        initrange = 0.5

        # 初始化embedding对应值得范围(均匀分布)
        self.embedding.weight.data.uniform_(-initrange, initrange)

        # 初始化fc层的值(均匀分布)
        self.fc.weight.data.uniform_(-initrange, initrange)

        # 初始化偏置的值
        self.fc.bias.data.zero_()

    def forward(self, text, offsets):
        """
        正向传播函数
        :param text: 输入文本的数值映射
        :param offsets: Bag的起始位置
        :return: 返回全连接层之后的结果
        """

        # 实现embeddingbag层
        embedded = self.embedding(text, offsets)

        # 通过全连接层
        return self.fc(embedded)


if __name__ == '__main__':
    # 定义部分变量
    input = torch.LongTensor([2, 4, 5, 7, 9, 2, 1, 6])
    offsets = torch.LongTensor([0, 4])

    # 类和方法调用
    ft = FastText(vocab_size=10, embed_dim=3, num_class=4)

    ret = ft(input, offsets)
    print(ret)
