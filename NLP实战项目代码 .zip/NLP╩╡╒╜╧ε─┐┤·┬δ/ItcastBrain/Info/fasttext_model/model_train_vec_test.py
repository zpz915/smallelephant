# coding:utf-8

import fasttext
import pandas as pd

# 设置迁移词向量的路径
word_vec_path = "./cc.zh.300.vec"
word_train_data_path = "./name_question.train.2"
word_valid_data_path = "./name_question.valid.2"

# 进行模型训练
# tips: 维度要和迁移词向量的维度相同(300)
model = fasttext.train_supervised(
    input=word_train_data_path,
    autotuneValidationFile=word_valid_data_path,
    autotuneDuration=600,
    wordNgrams=2,
    # dim=300,
    # pretrainedVectors=word_vec_path,

    # 领域内词向量迁移参数修改
    dim=150,
    pretrainedVectors="unsupervised_data.vec"
)

# 在验证集验证
valid_res = model.test(word_valid_data_path)
print(valid_res)
