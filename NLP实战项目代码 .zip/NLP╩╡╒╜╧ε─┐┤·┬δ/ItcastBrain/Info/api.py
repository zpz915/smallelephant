import re
from pyhanlp import *
import requests


# 提取content中的信息
def get_dialog_list_with_index(input_, key, length_limit):
    """
    提取content信息
    :param input_:所有的对话内容
    :param key: 提示是学员还是咨询师的对话内容
    :param length_limit: 长度限制
    :return: 获取之后的信息
    """

    dialog_list = []

    for index, item in enumerate(input_):
        # 进行文本切割
        for text in item[key].split("¥"):
            # 进行长度限制
            if len(text) <= length_limit:
                dialog_list.append([text, index])
    return dialog_list


############################################################
# 以下函数都已经实现过
############################################################
def get_school(IP: str, school_config: list):
    """获得意向校区函数
    Args:
      IP: 传入的地区，比如：'中国 辽宁 锦州'
      school_config: 校区的有限集，列表形式

    Return:
      结果字典，形如{'school': NAME}, NAME是具体的校区名
            若不存在则 NAME = 'unknown'
    """
    # 初始化返回结果，默认为'unknown'
    school_res = {"school": "unknown"}
    # 循环遍历校区的有限集列表
    for address in school_config:
        # 判断每个标准校区名是否在给定的地区中
        if address in IP:
            # 一旦存在，说明该学员当前在传智校区范围内
            # 默认他可能报名该校区的学习班
            school_res["school"] = address
            # 因为"报名校区"这件事本身是互斥的，因此一旦匹配即可停止循环
            break
        # 否则继续匹配
        else:
            continue
    # 最后返回结果
    return school_res


def _get_resubject_config(subject_config):
    """将学科配置字典进行key与value的交换变形，方便后续使用。
    eg: {'JavaEE': ['Java', 'java', ...]} ---> {'Java': 'JavaEE', 'java': 'JavaEE', ...}
    Args:
      subject_config: 原生的学科配置字典

    Return:
      反转后的学科配置字典
    """
    # 初始化反转后的学科配置字典的key和value组成的列表
    rekey = []
    revalue = []

    # 循环遍历原生学科配置字典的key和value
    for key, value in subject_config.items():
        # 反转后的学科配置字典的value是原生字典的key，
        # 这个key需要由len(value)个
        revalue += [key] * len(value)
        # 反转后的学科配置字典的value是原生字典的value
        rekey += value

    # 将两个列表zip成一个新的字典
    resubject = dict(zip(rekey, revalue))
    return resubject


def _search_entity(info: str, resubject) -> list:
    """根据反转的学科字典配置，在一段文本中找到可能的学科
    Args:
      info: 要查找是否存在学科实体的字符串
      resubject: 反转的学科字典配置

    Return:
      文本中可能存在的标准学科名字组成的列表
    """
    # 首先遍历反转学科字典的key，并将在info中出现的key存入列表
    entity = list(filter(lambda x: x in info, resubject.keys()))
    # 之后根据这些key在字典中，找到他们对应的value，
    # 因为value可能是相同的，因此使用set去重，最后将这些value返回
    entity = list(set(map(lambda x: resubject[x], entity)))
    return entity


def get_subject(fromTitle, user_dialog_list, subject_config):
    """获取意向学科函数
    Args:
      fromTitle: 专题页标题，这是咨询师系统能够采集到的辅助信息
      user_dialog_list: 学员的每一次对话组成的列表
      subject_config: 学科配置字典

    Return:
      意向学科字典，形如: {'subject': NAME}, NAME为具体学科名
    """
    # 与意向校区类似，首先初始化结果字典
    subject_res = {"subject": "unknown"}
    # 使用辅助函数_get_resubject_config获得反转后的学科配置字典
    resubject = _get_resubject_config(subject_config)
    # 将输入的学员对话列表转换成字符串，与反转配置字典一同作为参数传给_search_entity
    # 这样就可以得到在学员对话中可能存在的标准学科实体名字
    entity = _search_entity(" ".join(user_dialog_list), resubject)
    if len(entity) >= 1:
        subject_res["subject"] = entity[0]

    # 另外，如果entity列表中没有匹配到标准学科
    # 我们就需要借助fromTitle即专题页标题这个信息进行尝试
    else:
        # 我们需要在标题中查找可能的，因为标题内都是标准的学科名
        # 我们可以直接使用subject_config的key进行查找
        for subject in subject_config.keys():
            # 将所有匹配到的结果存入entity列表
            if subject in fromTitle:
                entity.append(subject)
            else:
                pass
        # 当然，对于在fromTitle中进行查找，是一定要求只能出现一个学科的
        # 因为有的专题页内容是"黑马首页python/JavaEE/前端/软件测试"，
        # 说明学生在首页就进行了咨询，无法据此判断意向
        # 所以，当entity长度为1时可以使用该内容，否则不可以
        if len(entity) == 1:
            subject_res["subject"] = entity[0]
    # 返回结果
    return subject_res


def get_number(user_dialog_list):
    """识别号码的函数
    Args:
      user_dialog_list: 用户每次对话组成的列表

    Return:
      号码识别结果，eg: {'phone': NUM1, 'wechat': NUM2, 'qq': NUM3}
    """
    # 首先还是将用户每次对话组成的列表转换成字符串
    text = " ".join(user_dialog_list)

    # 初始化结果字典，默认为"unknown"
    number_res = {"phone": "unknown", "wechat": "unknown", "qq": "unknown"}

    # 首先我们来识别最有价值的"手机号"
    # 这里使用的正则表达式非常简单，按照国内三大运营商的规则，
    # 手机号都是以1开头且不会出现11或12或10开头手机号
    pattern = r"[1][3-9][0-9]{9}"
    # 通过该正则进行匹配
    m = re.findall(pattern, text)
    # 如果匹配结果存在，而且要满足不重复的数字大于3，
    # 也就是说类似与13333333333这样高重复度的号码不可以
    # 经过业务调查，这类号码只是学员不愿透漏真实号码的表现
    if m and len(set(list(m[-1]))) > 3:
        # 在这里我们直接将满足条件的手机号码也设定为他的微信号
        # 和之前一样，如果匹配到多个我们将选择最后一个
        number_res["phone"] = number_res["wechat"] = m[-1]
    else:
        # 如果没有匹配到手机号，我们将匹配非手机号码形式的微信号
        # 根据微信的要求，自定义的非手机号微信将满足以下正则条件
        # （必须以字母开头，使用6-20字母，数字或下划线）
        pattern = r"[a-zA-Z][a-zA-Z0-9_-]{5,19}"
        m = re.findall(pattern, text)
        # 如果匹配结果存在且不重复的数字或字母个数大于4（这个数值由业务推荐）
        # 还要保证不可以都是由字母组成的
        if m and len(set(list(m[-1]))) > 4 and not m[-1].isalpha():
            # 这样我们就可以认为匹配到的最后一个号码为微信号
            number_res["wechat"] = m[-1]

    # 接下来我们要识别QQ号，因为QQ都是由数字构成，且规则较宽泛
    # 直接匹配很容易将手机号中的一部分识别为QQ号，
    # eg: 手机号：15802313245，QQ号为其中一部分：2313245
    # 因此，我们首先将识别成手机号或者微信号的号码从字符串中去除
    if number_res["phone"] != "unkonwn" or number_res["wechat"] != "unknown":
        # 这里使用replace方法，空字符串替代即去除
        text = text.replace(number_res["phone"], "").replace(number_res["wechat"], "")
    # 接着我们写QQ的正则表达式
    # 这里假设是从最少6位开始的，虽然存在5位的QQ号，但是以我们学员的年纪，
    # 使用5位QQ号出现的概率极低，可以忽略
    pattern = r"[1-9]\d{5,8}"
    m = re.findall(pattern, text)
    # 与之前一样，如果匹配结果存在且不重复个数大于3，则认定为合法的QQ号
    if m and len(set(list(m[-1]))) > 3:
        number_res["qq"] = m[-1]

    # 在实际对话内容中，我们发现一种特殊情况，有时用户qq是qq13241287的情况
    # 而上述规则会讲这种情况识别为微信号，但是实际为qq号的概率却非常大
    # 因此我们还要对识别后的微信号进行该种情况的检测和修正
    # 如果QQ或者qq在微信号中
    if "qq" in number_res["wechat"] or "QQ" in number_res["wechat"]:
        # 则去除掉QQ或qq的号码应该是QQ号
        number_res["qq"] = number_res["wechat"].replace("qq", "").replace("QQ", "")
        # 而微信号则变成"unknow"
        number_res["wechat"] = "unknown"
    return number_res


def get_name_with_server(
    user_dialog_list,
    user_dialog_list_with_index,
    teacher_dialog_list_with_index,
    baijiaxing
):
    """使用模型服务判断问题类型再确定回答范围
    Args:
      user_dialog_lis: 学员对话内容
      user_dialog_list_with_index: 学员对话内容及其索引
      teacher_dialog_list_with_index: 咨询师对话内容及其索引

    Return:
      字典形式的name_res：{'name': Name}
    """
    # 初始化结果列表，默认为unknown
    name_res = {"name": "unknown"}

    try:
        url = "http://0.0.0.0:5001/v1/is_name_question/"
        # 请求体数据：咨询师的对话内容和索引
        data = {"text": teacher_dialog_list_with_index}
        # 发送POST请求，超时限定为100ms
        res = requests.post(url, json=data, timeout=100)
    except Exception as e:
        # 若请求出问题则打印日志
        print(e)

    # 判断返回结果是否为-1，如果不是，说明有相关的姓名问题
    if res.text != "-1":
        # 循环遍历学员对话内容
        for content, index in user_dialog_list_with_index:
            # 找到和咨询师提及姓名问题相同的索引位置，
            # 该内容也就是学员对这个问题的回答
            if str(index) == res.text:
                # 判断学员是否只是回答了一个有关"姓氏"的字
                if content in baijiaxing:
                    # 返回姓氏+ 同学作为最终结果
                    name_res = {"name": content + "同学"}
                break
            else:
                # 使用之前的规则函数进行搜索
                name_res = get_name(user_dialog_list)
    # 返回结果
    return name_res


def get_name(user_dialog_list):
    """获得学员姓名函数
    Args:
      user_dialog_list: 学员对话组成的列表

    Return:
      获得的姓名结果字典
    """
    # 将对话列表转换成字符串
    text = " ".join(user_dialog_list)
    # 初始化结果字典，默认为unkonwn
    name_res = {"name": "unknown"}

    # 判断"姓"字是否出现，如果出现则代表学员可能回答了姓氏
    if "姓" in text:
        try:
            # 直接查找"姓"字的下一个，因为这样直接索引加1可能越界
            # 因此使用try进行保护
            res = text[text.index("姓") + 1]
            # 如果res是一个中文汉字，则认为它是这个学员的姓氏
            # 咨询师习惯把只透漏姓氏的学员称为x同学
            if "\u4e00" <= res <= "\u9fa5":
                name_res["name"] = res + "同学"
        # 如果发生越界等错误，则打印错误信息即可
        except Exception as e:
            print(e)
    # 如果没有出现"姓"字，那就有可能学员回答了姓名（也有可能根本没提及姓名）
    else:
        # 我们使用hanlp中的中文人名识别功能来查找可能出现姓名
        # 使用segment方法对文本进行分割
        r = HanLP.segment(text)
        # 过滤出所有属性为"nr"的实体，nr代表人名
        name_tmp = list(filter(lambda x: str(x.nature) == "nr", r))
        # 如果结果存在，我们则认为最后一个出现的nr是学员的名字
        if name_tmp:
            name_res["name"] = name_tmp[-1].word
    return name_res
