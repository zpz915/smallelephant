var searchData=
[
  ['dictionary',['Dictionary',['../classfasttext_1_1Dictionary.html',1,'fasttext']]]
];
