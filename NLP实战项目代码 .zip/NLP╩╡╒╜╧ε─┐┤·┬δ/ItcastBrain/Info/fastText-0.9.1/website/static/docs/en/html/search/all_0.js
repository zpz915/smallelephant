var searchData=
[
  ['add',['add',['../classfasttext_1_1Dictionary.html#a596c4c5f5ebf71c228abf1831e216a56',1,'fasttext::Dictionary']]],
  ['addcode',['addcode',['../classfasttext_1_1ProductQuantizer.html#ac0039e0eccfc7dc15ddb3be3bac0fec3',1,'fasttext::ProductQuantizer']]],
  ['addrow',['addRow',['../classfasttext_1_1Matrix.html#aceef1bc55d67b38c8b2b2c9ba7e769de',1,'fasttext::Matrix::addRow()'],['../classfasttext_1_1Vector.html#a94d369014b965b42ead2deb5e3fa0b11',1,'fasttext::Vector::addRow(const Matrix &amp;, int64_t)'],['../classfasttext_1_1Vector.html#a100ad4f70094b54b84e43909da7be040',1,'fasttext::Vector::addRow(const QMatrix &amp;, int64_t)'],['../classfasttext_1_1Vector.html#a29196e26f7258ba61d7ea4d19c4b14a7',1,'fasttext::Vector::addRow(const Matrix &amp;, int64_t, real)']]],
  ['addtovector',['addToVector',['../classfasttext_1_1QMatrix.html#ad8f153a45f69530aeef171bebbce93fc',1,'fasttext::QMatrix']]],
  ['addvector',['addVector',['../classfasttext_1_1Vector.html#aef57a1c3a853b8691f544e9f881a3394',1,'fasttext::Vector::addVector(const Vector &amp;source)'],['../classfasttext_1_1Vector.html#a1bdce14007d4b8878a3a3dd36b467e95',1,'fasttext::Vector::addVector(const Vector &amp;, real)']]],
  ['addwordngrams',['addWordNgrams',['../classfasttext_1_1Dictionary.html#a6f0cbb4f3b99e9cefde82c7cfe9f2e1c',1,'fasttext::Dictionary']]],
  ['analogies',['analogies',['../classfasttext_1_1FastText.html#a34e7fade7f758870ffcd28015555ba74',1,'fasttext::FastText::analogies()'],['../main_8cc.html#a7ffcd938d3c75d2f9249d6c122b780a4',1,'analogies():&#160;main.cc']]],
  ['argmax',['argmax',['../classfasttext_1_1Vector.html#a5ca06ee0880c24409faad3e69a920d9a',1,'fasttext::Vector']]],
  ['args',['Args',['../classfasttext_1_1Args.html',1,'fasttext::Args'],['../classfasttext_1_1Args.html#ab196dccd500190c3831af2cbfdd3eb03',1,'fasttext::Args::Args()']]],
  ['args_2ecc',['args.cc',['../args_8cc.html',1,'']]],
  ['args_2eh',['args.h',['../args_8h.html',1,'']]],
  ['args_5f',['args_',['../classfasttext_1_1Dictionary.html#a6deee7ff65d22fc2509702dcc48bb889',1,'fasttext::Dictionary::args_()'],['../classfasttext_1_1FastText.html#adb5bfe8d98e11ae5dd3498f9ee4829ee',1,'fasttext::FastText::args_()'],['../classfasttext_1_1Model.html#a76314e94e2582e9e2160bcfd9c75ba99',1,'fasttext::Model::args_()']]],
  ['assign_5fcentroid',['assign_centroid',['../classfasttext_1_1ProductQuantizer.html#aa957e4e92eb6111152f6e34b0b4a27cd',1,'fasttext::ProductQuantizer']]],
  ['at',['at',['../classfasttext_1_1Matrix.html#afc9c477f90e9d9a193e1710e46a68221',1,'fasttext::Matrix::at(int64_t i, int64_t j) const'],['../classfasttext_1_1Matrix.html#abb6222f956da7e32391092158eaaf5a0',1,'fasttext::Matrix::at(int64_t i, int64_t j)']]]
];
