from django.http import HttpResponse, StreamingHttpResponse, FileResponse
from rest_framework import viewsets
from rest_framework.response import Response
from rest_framework.decorators import api_view
from rest_framework.authentication import SessionAuthentication, BasicAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.decorators import authentication_classes
from rest_framework.decorators import permission_classes

# 引入同目录下的api.py和config.py
from . import api
from . import config

import json


# 通过装饰器确定,接收的是post请求,
@api_view(["POST"])
def get_info(request):
    """
    获取系统结果的主要函数
    :param request: 请求体,就是之前确定的标准输入的json数据格式
    :return: response:响应体,输出的是json标准的数据格式
    """

    # 通过request获取标准数据
    data = json.loads(request.body.decode())

    # 通过get_dialog_list_index函数获取对应的数据,ps:该函数等会会在api文件中实现
    # 获取老师对话内容和索引
    teacher_dialog_list_with_index = api.get_dialog_list_with_index(
        data["content"], config.teacher_key, config.teacher_length_limit
    )

    # 获取学员对话内容和索引
    user_dialog_list_with_index = api.get_dialog_list_with_index(
        data["content"], config.user_key, config.user_length_limit
    )

    # 提取学员对话内容中的文本
    if user_dialog_list_with_index:
        user_dialog_list = list(map(lambda x: x[0], user_dialog_list_with_index))
    else:
        user_dialog_list = []

    # 根据前面提取到的数据,调用api中的函数,然后提取对应信息
    # 提取意向学科
    subject_res = api.get_subject(data["fromTitle"], user_dialog_list, config.subjects)

    # 提取意向校区
    school_res = api.get_school(data["ip"], config.schools)

    # 获取学员手机号,QQ号等内容
    number_res = api.get_number(user_dialog_list)

    # 获取学员姓名或者姓氏
    name_res = api.get_name_with_server(
        user_dialog_list,
        user_dialog_list_with_index,
        teacher_dialog_list_with_index,
        config.baijiaxing
    )

    # 构造返回的res对应内容
    res = {"sessionId": data["sessionId"]}
    # 填充意向校区\学科等内容
    res.update(subject_res)
    res.update(school_res)
    res.update(number_res)
    res.update(name_res)

    # 返回封装好的响应体
    return Response(res)
