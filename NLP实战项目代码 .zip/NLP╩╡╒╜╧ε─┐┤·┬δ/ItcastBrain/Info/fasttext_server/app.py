# coding:utf-8

# ==================
# # flask基本使用
# # 第一步: 导入
# from flask import Flask
#
# # 第二步: 创建flask实例
# app = Flask(__name__)
#
#
# # 第三步: 定义视图函数,并设置视图函数的路由
# @app.route("/")
# def hello_world():
#     """
#     q请求指定的url,然后执行的主要逻辑函数
#     :return: 返回对应内容,此处返回字符串
#     """
#     return "hello itcast"
#
#
# # 第四步: 运行flask实例
# if __name__ == '__main__':
#     app.run(host="0.0.0.0", port=5001)


# ==================
# 使用Flask框架将模型封装成服务
from flask import Flask, request

import fasttext
import jieba

app = Flask(__name__)

# 寻找最新模型
model_name = "name_question_1605274039.bin"
model_path = "/data/ItcastBrain/Info/fasttext_model/" + model_name

# 加载模型
model = fasttext.load_model(model_path)


# 定义服务的请求路径和方式
@app.route("/v1/is_name_question/", methods=["POST"])
def recognizition():
    """
    姓名问题识别函数
    输入: [[咨询师说的话 索引], [咨询师说的话 索引], [咨询师说的话 索引]]
    输出: 最后如果检测到某句话是询问姓名,返回对应索引,如果都不是,返回-1
    :return: index
    """
    # 获取相关数据
    text = request.get_json()["text"]

    result = -1

    # 循环遍历对话内容和索引
    for te, index in text:
        predicted = model.predict(" ".join(jieba.cut(te)))
        if predicted[0][0] == "__label__name":
            result = index
            break
    return str(result)
