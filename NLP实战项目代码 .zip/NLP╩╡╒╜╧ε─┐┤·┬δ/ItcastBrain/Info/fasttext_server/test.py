# coding:utf-8

import requests
import time

# 根据gunicorn开启的5001端口,以及app.py中的url路径,进行相应的执行
url = "http://0.0.0.0:5001/v1/is_name_question/"
data = {
    "text": [
        ["您好,您贵姓?", 1],
        ["您想了解哪个专业的学费呢", 2],
        ["专业不同，学时学费也不一样", 3],
        ["好的，方便QQ或者微信，邮箱接收吗？我这边发您", 4],
    ]
}

start = time.time()

res = requests.post(url, json=data, timeout=200)

end = time.time()

print(end-start)
print(res.text)