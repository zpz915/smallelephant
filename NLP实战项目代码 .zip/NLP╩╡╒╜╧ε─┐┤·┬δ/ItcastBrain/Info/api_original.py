# coding:utf-8

# 导入必备的工具包
import re
from pyhanlp import *
import requests


def get_dialog_list_with_index(input_, key, length_limit):
    """提取conetnt并附带索引
    Args:
      input_: list, 所有的对话内容
      key: 指明提取学员/咨询师的对话内容
      length_limit: 对话长度限制，超限数据将被过滤
    """
    # 初始化结果列表
    dialog_list = []
    # 循环遍历对话内容
    for index, item in enumerate(input_):
        # 选定指明的key并对文本进行分割
        for text in item[key].split("¥"):
            # 留下所有长度小于length_limit的句子
            if len(text) <= length_limit:
                # 将内容和索引存入列表之中
                dialog_list.append([text, index])
    return dialog_list



# ==============================
# 获取意向校区

# 传智校区的有限集
school_config = [
    "北京",
    "深圳",
    "广州",
    "上海",
    "郑州",
    "杭州",
    "武汉",
    "西安",
    "南京",
    "长沙",
    "成都",
    "济南",
    "合肥",
    "厦门",
    "太原",
    "石家庄",
    "重庆",
    "沈阳",
    "天津",
]


def get_school(IP, school_config):
    """
    :param IP: 传入的地区: 比如:中国 北京 北京
    :param school_config: 校区组成的列表
    :return: 返回形式:1.{"school": NAME}, NAME是具体的校区名; 2.{"school": unknown}, 代表没有匹配到校区
    """

    # 首先初始化返回结果
    school_res = {"school": "unknown"}

    # 进行循环遍历,查看是否有满足要求的地区
    for address in school_config:
        # 开始判断,如果在有限集中,执行if
        if address in IP:
            school_res["school"] = address
            # 因为选择校区是一个互斥事件,所以选中之后,跳出循环
            break
        # 如果上面不满足要求,继续匹配
        else:
            continue
    return school_res


# if __name__ == '__main__':
#     IP = "中国北京北京"
#     school_res = get_school(IP, school_config)
#     print(school_res)


# ==============================
# 获取意向学科

# 给定学科的有限集，不过这次的有限集与校区有限集不同
# 因为这次的匹配搜索是在学员的对话中进行，
# 学员可能针对同一学科有不同的输入形式，如：JavaEE 可以是 Java 或 JAVA等等。
# 因此，我们这次的学科有限集是一个字典形式，字典的key为标准学科名称，
# value则是这个学科名可能的变体组成的列表。如下所示：
# (这些变体都是由业务人员提供的常见形式)

subjects = {
    "JavaEE": ["Java", "JAVA", "jave", "java", "JavaEE"],
    "Python": ["python", "pythen", "PY", "PYTHON"],
    "大数据": ["大数据"],
    "C++": ["C++", "c", "C", "c++", "c+"],
    "UI设计": ["ui", "UI", "Ui", "uI"],
    "产品经理": ["产品", "产品经理"],
    "视觉设计": ["视觉设计"],
    "前端与移动开发": ["前端", "移动开发"],
    "软件测试": ["测试"],
    "影视制作": ["影视制作"],
    "PMP认证": ["PMP认证"],
    "在线学习": ["在线学习"],
    "物联网区块链": ["物联网", "区块链"],
    "机器人开发": ["机器人"],
    "微信小程序": ["微信小程序"],
    "全栈": ["全栈"],
    "新媒体": ["新媒体", "短视频"],
    "电商运营": ["电商运营"],
    "PHP": ["PHP", "php", "Php"],
    "Linux运维": ["Linux", "运维"],
    "Go区块链": ["Go", "go"],
    "Java架构师": ["架构师", "Java架构师"],
}


def _get_resubject_config(subject_config):
    """
    把学科配置内容反转,并且转换为1:1的模式
    eg:{'JavaEE': ['Java', 'java', ...]} ---> {'Java': 'JavaEE', 'java': 'JavaEE', ...}
    :param subject_config: 最初构建的字典
    :return:反转之后对应的字典
    """

    # 反转后,承接字典中的键值对内容
    rekey = []
    revalue = []

    # 循环遍历原生学科对应的键值对
    for key, value in subject_config.items():
        # 反转之后,所有值都一样,所以直接拼接
        revalue += [key] * len(value)
        # 原来字典中的值,反过来变成键,进行使用
        rekey += value

    # 把rekey, revalue组成一个新的dict
    resubject = dict(zip(rekey, revalue))
    return resubject


# 第二个辅助函数_search_entity
def _search_entity(info, resubject):
    """
    根据前面反转之后的学科字典,在一段文本(学员说的内容)中找到可能出现的学科
    :param info: 要查找是否可能存在学科名字的字符串 -- "c++ 多少钱 我的qq121122345"
    :param resubject反转的学科字典配置
    :return:文本中可能存在的标准学科名字组成的列表
    """
    # 遍历反转学科字典的键,讲info中出现的键存入到列表中
    entity = list(filter(lambda x: x in info, resubject.keys()))
    # print("entity:", entity)

    # 根据这些key,找到对应字典中的value
    entity = list(map(lambda x: resubject[x], entity))
    # print("entity:", entity)

    return entity


# 获取意向学科函数
def get_subject(fromTitle, user_dialog_list, subject_config):
    """
    获取意向学科函数
    :param formTitle: 专题页标题
    :param user_dialog_list: 学员每一次对话内容组成的列表
    :param subject_config: 学科配置的字典
    :return: {"subject": NAME}
    """

    # 初始化学科字典
    subject_res = {"subject": "unknown"}

    # 使用辅助函数,反转学科配置字典
    resubject = _get_resubject_config(subject_config)

    # 调用第二个辅助函数,获取学员对话中,可能出现的学科名
    # tips: 我们获取到的是学员对话内容的列表,需要把其转换为字符串
    entity = _search_entity(info=" ".join(user_dialog_list), resubject=resubject)

    # 因为标准学科只能填写一个,我们获取出现的第一个
    if len(entity) >= 1:
        subject_res["subject"] = entity[0]

    # 如果没有匹配到标准学科,此时需要求助于fromTitle 中的内容
    else:
        for subject in subject_config.keys():
            if subject in fromTitle:
                entity.append(subject)
            else:
                pass
        # 通过标题页获取到的学科名,只能是出现一个,
        # 如果学员通过专题页咨询过多个学科,此时没法进行判断
        if len(entity) == 1:
            subject_res["subject"] = entity[0]

    # 返回最后的结果
    return subject_res


# if __name__ == '__main__':
#     # resubject = _get_resubject_config(subjects)
#     # print(resubject)
#
#     # info = "c++ 多少钱 我的qq121122345"
#     # entity = _search_entity(info, resubject)
#
#     fromTitle = "黑马程序员C/C++与网络攻防培训官网-C/C++培训|C/C++与网络攻防培训机构"
#     user_dialog_list = ["c++", "多少钱", "我的qq121122345"]
#     ret = get_subject(fromTitle, user_dialog_list, subjects)
#     print(ret)

# ==============================
# "手机号"，"微信号"，"QQ号"识别
import re


def get_number(user_dialog_list):
    """
    识别"手机号"，"微信号"，"QQ号"
    :param user_dialog_list: 学员每次说话组成的列表
    :return: 各个号码识别的一个结果-字典形式: {"phoneNum": 13200231234, "wechat": num2, }
    """

    # 把学员对话转换为一个长字符串
    text = " ".join(user_dialog_list)

    # 初始化字典内容
    number_res = {"phone": "unknown", "wechat": "unknown", "qq": "unknown"}

    # 开始匹配手机号
    pattern = r"[1][3-9][0-9]{9}"
    m = re.findall(pattern, text)

    # 在上面的基础上,继续判断手机号和微信号
    if m and len(set(list(m[-1]))) > 3:
        # 如果在查找到的内容中,发现满足上面要求,此时把匹配到的值,赋值给微信和手机号
        number_res["phone"] = number_res["wechat"] = m[-1]
    # 如果没有匹配到手机号,此时我们要根据微信的规则,匹配微信号
    else:
        # 微信规则:要以字母开头,使用6-20个字母\数字\下划线
        pattern = r"[a-zA-Z][a-zA-Z0-9_-]{5,19}"
        m = re.findall(pattern, text)

        # 如果匹配到需要内容
        if m and len(set(list(m[-1]))) > 4:
            # 在此处制定的规则中,数字4 是根据业务自己确定
            number_res["wechat"] = m[-1]

    # 打印查看手机号和微信号
    # print(number_res)

    # 开始检测QQ号内容
    # 首先,QQ号和手机号都可能是数字,且QQ号可能被检测成手机号中的一部分数字,
    # 所以,在进行检测之前,需要把之前检测到的微信号,手机号去除
    if number_res["phone"] != "unknown" or number_res["wechat"] != "unknown":
        # 此时进行替换
        text = text.replace(number_res["phone"], "").replace(number_res["wechat"], "")
        # print(text)

    # 检测手机号开始
    pattern = r"[1-9]\d{5,10}"
    m = re.findall(pattern, text)

    if m and len(set(list(m[-1]))) > 3:
        number_res["qq"] = m[-1]
    # print(number_res)

    # 有些时候,学员会把QQ号码写成:"我的qq121122345",但是根据我们的规则,把这种模式检测为微信号,
    # 此时我们要进行处理
    if "qq" in number_res["wechat"] or "QQ" in number_res["wechat"]:
        # 去除qq,然后把对应数字放到QQ位置
        number_res["qq"] = number_res["wechat"].replace("qq", "").replace("QQ", "")
        number_res["wechat"] = "unknown"
    return number_res


# if __name__ == '__main__':
#     user_dialog_list = ["c++", "多少钱", "我的qq121122345", "手机1522222222", "23456432"]
#     number_res = get_number(user_dialog_list)
#     print(number_res)

# ==============================
# "姓名"识别（规则解决）

from pyhanlp import HanLP


def get_name(user_dialog_list):
    """
    获取学员姓名
    :param user_dialog_list: 学员对话组成的一个列表
    :return: 获取学员姓名的字典 {"name": "张三"}
    """
    # 把对话列表转换为字符串
    text = " ".join(user_dialog_list)

    # 初始化对应姓名字典
    name_res = {"name": "unknown"}

    # 根据学员对话内容,判断姓名
    # 判断是否出现"姓"
    if "姓" in text:
        try:
            res = text[text.index("姓") + 1]
            # 判断检测到的res是否是汉子,如果是,直接在后面添加*同学,就OK
            if "\u4e00" <= res <= "\u9fa5":
                name_res["name"] = res + "同学"
        except Exception as e:
            print(e)
    # print(name_res)

    # 如果没有出现"姓"字,通过hanlp检测学员姓名
    else:
        r = HanLP.segment(text)
        name_temp = list(filter(lambda x: str(x.nature) == "nr", r))
        if name_temp:
            name_res["name"] = name_temp[-1].word

    return name_res


# if __name__ == '__main__':
#     user_dialog_list = ["周杰伦"]
#     name_res = get_name(user_dialog_list)
#     print(name_res)

# ==============================
# "姓名"识别（使用模型）
import requests

# 百家姓列表，取对话领域最常出现的100个姓氏
baijiaxing = ['李', '张', '冯', '王', '刘', '杨', '陈', '赵', '黄', '周', '吴', '徐',
              '郑', '马', '朱', '胡', '郭', '何', '高', '林', '罗', '孙', '梁', '谢', '宋', '唐',
              '许', '韩', '邓', '曹', '彭', '曾', '萧', '田', '董', '潘', '袁', '于', '蒋', '蔡',
              '余', '杜', '叶', '程', '苏', '魏', '吕', '丁', '任', '沈', '姚', '卢', '姜', '崔',
              '钟', '谭', '陆', '汪', '范', '金', '石', '廖', '贾', '夏', '韦', '傅', '方', '白',
              '邹', '孟', '熊', '秦', '邱', '江', '尹', '薛', '阎', '段', '雷', '侯', '龙', '史',
              '陶', '黎', '贺', '顾', '毛', '郝', '龚', '邵', '万', '钱', '严', '覃', '河', '戴',
              '莫', '孔', '向', '汤']


def get_name_with_server(
        user_dialog_list, user_dialog_list_with_index, teacher_dialog_list_with_index
):
    """
    使用模型服务判断问题类型,最后确定姓名所在范围
    :param user_dialog_list: 学员对话内容
    :param user_dialog_list_with_index:学员对话内容和索引
    :param teacher_dialog_list_with_index: 咨询师对话内容和索引
    :return:  name_res : {"name": "李同学"}
    """
    # 初始化结果列表:
    name_res = {"name": "unknown"}

    # 通过try-except获取响应内容
    try:
        url = "http://0.0.0.0:5001/v1/is_name_question/"
        data = {"text": teacher_dialog_list_with_index}
        # 发送post请求
        res = requests.post(url, json=data, timeout=100)
    except Exception as e:
        # 如果请求出问题,则打印对应日志
        print(e)

    # 如果返回的结果为-1,则说明里面没有姓名提问,如果不是,则说明有姓名相关提问
    if res.text != -1:
        # 遍历学员对话内容
        for content, index in user_dialog_list_with_index:
            # 此处判断是否有对应提问内容
            if str(index) == res.text:
                # 判断是否在百家姓中
                if content in baijiaxing:
                    name_res = {"name": content + "同学"}
                break
            else:
                name_res = get_name(user_dialog_list)

    return name_res


if __name__ == '__main__':
    teacher_dialog_list_with_index = [["您好", 1], ["您贵姓", 2]]
    user_dialog_list_with_inde = [["李", 2]]
    user_dialog_list = ["李"]
    name_res = get_name_with_server(user_dialog_list, user_dialog_list_with_inde, teacher_dialog_list_with_index)
    print(name_res)
