# coding:utf-8

from django.http import HttpResponse, StreamingHttpResponse, FileResponse
from rest_framework import viewsets
from rest_framework.response import Response
from rest_framework.decorators import api_view
from rest_framework.authentication import SessionAuthentication, BasicAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.decorators import authentication_classes
from rest_framework.decorators import permission_classes

# 引入同目录下的api.py和config.py
from . import api_original
from . import config

# 接受POST请求，也就是url.py中指向的get_info函数
@api_view(["POST"])
def get_info(request):
    """
    服务中获取系统结果的主函数
    request为请求体，其中包含之前定义的标准输入JSON格式
    我们将返回一个响应体，包含之前定义的标准输出JSON格式
    """
    # 解析请求体, 获得标准的输入数据
    data = json.loads(request.body.decode())

    # 使用对api中的get_dialog_list_with_index函数对输入的JOSN进行解析，
    # 获得咨询师对话内容和索引组成的列表，关于具体的参数和函数内容将在api.py中讲解
    teacher_dialog_list_with_index = api_original.get_dialog_list_with_index(
        data["content"], config.teacher_key, config.teacher_length_limit
    )

    # 同上，获得学员对话内容和索引组成的列表
    user_dialog_list_with_index = api_original.get_dialog_list_with_index(
        data["content"], config.user_key, config.user_length_limit
    )

    # 通过user_dialog_list_with_index来获得user_dialog_list，不需要再调用函数
    if user_dialog_list_with_index:
        user_dialog_list = list(map(lambda x: x[0], user_dialog_list_with_index))
    else:
        user_dialog_list = []

    # 下面这些函数我们已经在之前实现，以下为调用过程
    # 获得意向学科
    subject_res = api_original.get_subject(data["fromTitle"], user_dialog_list, config.subjects)
    # 获得意向校区
    school_res = api_original.get_school(data["ip"], config.schools)
    # 获得学员有关的号码（手机号，微信号，QQ号）
    number_res = api_original.get_number(user_dialog_list)
    # 获得学员的姓氏或姓名
    name_res = api_original.get_name_with_server(
        user_dialog_list,
        user_dialog_list_with_index,
        teacher_dialog_list_with_index,
        config.baijiaxing
    )
    # sessionId不变
    res = {"sessionId": data["sessionId"]}
    # 所有内容存入字典
    res.update(subject_res)
    res.update(school_res)
    res.update(number_res)
    res.update(name_res)
    # 封装响应体进行返回
    return Response(res)

